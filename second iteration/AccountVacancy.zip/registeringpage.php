<html>
	<head>
		<title>registeringpage</title>
		<link href = "empty.jpg" rel="icon" type="image/jpg"> 
		</head>
	<style>
	p.one
	{
		font-family:'Times New Roman';font-size:1.2em;color:Black;
		position:absolute;
		right:20px;
		top:45px;
	}
	p.two
	{
		position:absolute;
		left:10px;
		font-size : 30px;
	}
	hr.hOne
	{
	position:absolute;
	top:84px;
	color: black; background:black; width: 98.8%; height: 5px;
	border: black;
	}
	</style>
	<body>
		<div style='background-color:#00d2ff;'>
			<img src='Picture1.png' width = '727px' height = '79px'><p class = 'one'>welcome user&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
			<hr class ='hOne'>
		</div>
		<body background = "Background1.jpg">
	<p class = 'two'>Thank you for registering on our website.<br>An automatically generated mail containing your account password has been mailed to you. We recommend you to change your password ASAP.</p>
	</body>
</html>